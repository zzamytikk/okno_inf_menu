var z = {
  $:q => {
    //document.querySelectorAll('#id')[0].innerHTML='querySelectorAll';
    //console.error('querySelector', document.querySelector('#id'));//.innerHTML='querySelector';
    //document.getElementById('id').innerHTML='123';
    
    //console.error();
    
    $('#id').html('321');
  }
};
  //console.error('start');
z.$();
